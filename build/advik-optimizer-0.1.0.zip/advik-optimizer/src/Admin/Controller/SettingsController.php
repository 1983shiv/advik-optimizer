<?php

declare(strict_types=1);

namespace AdvikLabs\Optimizer\Admin\Controller;

use AdvikLabs\Optimizer\Support\SettingsRegistry;
use AdvikLabs\Optimizer\Admin\View\SettingsView;
use AdvikLabs\Optimizer\Domain\Cache\Service\CachePurgeService;
use AdvikLabs\Optimizer\Domain\Image\Repository\ImageOptimizationRepository;
use AdvikLabs\Optimizer\Domain\Minify\Repository\CriticalCssRepository;

class SettingsController extends AbstractController {

	private SettingsRegistry $registry;
	private SettingsView $view;
	private CachePurgeService $purgeService;
	private ?ImageOptimizationRepository $imageRepo;
	private ?CriticalCssRepository $criticalCssRepo;

	public function __construct(
		SettingsRegistry $registry,
		SettingsView $view,
		CachePurgeService $purgeService,
		?ImageOptimizationRepository $imageRepo = null,
		?CriticalCssRepository $criticalCssRepo = null
	) {
		$this->registry        = $registry;
		$this->view            = $view;
		$this->purgeService    = $purgeService;
		$this->imageRepo       = $imageRepo;
		$this->criticalCssRepo = $criticalCssRepo;
	}

	public function index(): void {
		$this->verifyCapability();

		$tab      = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'cache';
		$settings = get_option( 'advik_optimizer_settings', [] );
		$template = match ( $tab ) {
			'vitals' => 'settings-vitals',
			'images' => 'settings-images',
			'minify' => 'settings-minify',
			default  => 'settings-cache',
		};

		$extra = [];

		if ( 'images' === $tab && null !== $this->imageRepo ) {
			$extra['queue'] = $this->imageRepo->getAll();
		}

		if ( 'minify' === $tab && null !== $this->criticalCssRepo ) {
			$extra['lastScanTime'] = $this->criticalCssRepo->getLastScanTime();
			$extra['ruleCount']    = $this->criticalCssRepo->getRuleCount();
		}

		$this->view->render(
			$template,
			array_merge(
				[
					'tab'      => $tab,
					'settings' => $settings,
					'fields'   => $this->registry->getFields(),
				],
				$extra
			)
		);
	}

	private function getFieldsForTab( string $tab ): array {
		$tabMap = [
			'cache'  => [ 'module_cache', 'cache_ttl', 'exclude_logged_in', 'excluded_urls', 'cache_warming' ],
			'images' => [ 'module_images', 'image_quality', 'image_format', 'image_lazy_loading' ],
			'minify' => [ 'module_minify', 'minify_css', 'minify_js', 'minify_html', 'minify_exclude_css', 'minify_exclude_js' ],
			'vitals' => [ 'module_vitals', 'vitals_sampling_rate', 'vitals_psi_api_key', 'vitals_alert_lcp', 'vitals_alert_cls', 'vitals_alert_inp', 'vitals_alert_email', 'vitals_alert_email_address', 'vitals_alert_webhook', 'vitals_webhook_url' ],
		];

		return $tabMap[ $tab ] ?? [];
	}

	public function save(): void {
		$this->verifyCapability();
		check_admin_referer( 'advik_optimizer_save_settings' );

		$tab      = isset( $_POST['tab'] ) ? sanitize_key( wp_unslash( $_POST['tab'] ) ) : 'cache';
		$settings = get_option( 'advik_optimizer_settings', [] );
		$fields   = $this->registry->getFields();

		$tabFields = $this->getFieldsForTab( $tab );

		foreach ( $fields as $key => $config ) {
			if ( isset( $_POST[ $key ] ) ) {
				$raw   = wp_unslash( $_POST[ $key ] );
				$value = $raw;

				if ( is_callable( $config['sanitize'] ?? '' ) ) {
					$value = call_user_func( $config['sanitize'], $value );
				} else {
					$value = sanitize_text_field( $value );
				}

				if ( 'checkbox' === $config['type'] ) {
					$value = filter_var( $value, FILTER_VALIDATE_BOOLEAN );
				}

				$settings[ $key ] = $value;
			} elseif ( 'checkbox' === ( $config['type'] ?? '' ) && in_array( $key, $tabFields, true ) ) {
				$settings[ $key ] = false;
			}
		}

		update_option( 'advik_optimizer_settings', $settings );

		$purgeCache = isset( $_POST['purge_cache'] ) ? sanitize_key( wp_unslash( $_POST['purge_cache'] ) ) : '';
		if ( ! empty( $purgeCache ) ) {
			$scope = isset( $_POST['purge_scope'] ) ? sanitize_key( wp_unslash( $_POST['purge_scope'] ) ) : 'all';
			$this->purgeService->purge( [ 'scope' => $scope ] );
		}

		wp_safe_redirect(
			add_query_arg(
				[
					'page'  => 'advik-optimizer-settings',
					'tab'   => $tab,
					'saved' => '1',
				],
				admin_url( 'admin.php' )
			)
		);
		exit;
	}
}
